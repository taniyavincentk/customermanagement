package com.cognizant.project.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cognizant.project.dao.CustomerDAO;
import com.cognizant.project.entity.Customer;



@Transactional
@Service
public class CustomerServiceImp implements CustomerService {

@Autowired
CustomerDAO customerDao;


@Override
@Transactional
public List<Customer> getAllCustomers()
{
return customerDao.getAllCustomers();
}


@Override
@Transactional
public void saveCustomer(Customer cust) {
customerDao.saveCustomer(cust);
}


@Override
@Transactional
public Customer getCustomer(int theId)
{
return customerDao.getCustomer(theId);
}


@Override
@Transactional
public void deleteCustomer(int theId)
{
customerDao.deleteCustomer(theId);
}


@Override
@Transactional
public List<Customer> getCustomerbyNameorId(String val) {
	
	return customerDao.getCustomerbyNameorId(val);
}




}




