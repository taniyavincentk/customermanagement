package com.cognizant.project.entity;



import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;


@Entity
@Table(name="customer")
public class Customer {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
 private int id;
	@NotEmpty(message="first name cannot be null")
	
	@Column(name="first_name")	
 private String firstName;
	@NotEmpty(message="last name cannot be null")
	@Column(name="last_name")	
 private String lastName;


//@DateTimeFormat(iso=ISO.DATE)
//@DateTimeFormat(pattern="yyyy-MM-dd")
//@NotNull(message="Enter a valid date")

 private Date dob;
@NotEmpty(message="gender cannot be null")
 private String gender;
@NotEmpty(message="email cannot be null")
@Email
 private String email;
@NotEmpty(message="Phn no cannot be null")
 private String phn;

public Customer() {
	
}

public Customer( String firstName, String lastName, Date dob, String gender, String email, String phn) {
	
	
	this.firstName = firstName;
	this.lastName = lastName;
	this.dob = dob;
	this.gender = gender;
	this.email = email;
	this.phn = phn;
}

public int getId() {
	return id;
}

public void setId(int id) {
	this.id = id;
}

public String getFirstName() {
	return firstName;
}

public void setFirstName(String firstName) {
	this.firstName = firstName;
}

public String getLastName() {
	return lastName;
}

public void setLastName(String lastName) {
	this.lastName = lastName;
}

public Date getDob() {
	return dob;
}

public void setDob(Date dob) {
	this.dob = dob;
}

public String getGender() {
	return gender;
}

public void setGender(String gender) {
	this.gender = gender;
}

public String getEmail() {
	return email;
}

public void setEmail(String email) {
	this.email = email;
}

public String getPhn() {
	return phn;
}

public void setPhn(String phn) {
	this.phn = phn;
}

@Override
public String toString() {
	return "Customer [id=" + id + ", firstName=" + firstName + ", lastName=" + lastName + ", dob=" + dob + ", gender="
			+ gender + ", email=" + email + ", phn=" + phn + "]";
}
 
 
}
