package com.cognizant.project.dao;

import java.util.List;

import com.cognizant.project.entity.Customer;

public interface CustomerDAO {
   public List<Customer> getAllCustomers();

public void saveCustomer(Customer cust);


public void deleteCustomer(int theId);

public Customer getCustomer(int theId);

public List<Customer> getCustomerbyNameorId(String val);
   
}
