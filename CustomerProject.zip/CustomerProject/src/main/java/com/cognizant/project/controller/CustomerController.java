package com.cognizant.project.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cognizant.project.entity.Customer;
import com.cognizant.project.service.CustomerService;

@Controller
@RequestMapping("/customer")
public class CustomerController {
@Autowired
CustomerService customerService;


@GetMapping("showlogin")
public String showLogin(Model theModel) {
	return "login";
	
}
@RequestMapping("/loginCustomer")
@Transactional
public String loginForm(@RequestParam("username") String user,@RequestParam("password") String pass,Model msg) {
	try {
	if(user.equalsIgnoreCase("admin")&&(pass.equals("admin123"))) {
		return "redirect:/customer/list";
	}
	else {
		msg.addAttribute("msg","Invalid Credentials");
		return "login";
	}
	}
	catch(Exception e) {
		msg.addAttribute("msg","Invalid Credentials");
		return "login";
	}
}

//@RequestMapping("/list")
@GetMapping("/list")
public String listCustomer(Model model) {
List<Customer> listCustomers = customerService.getAllCustomers();
model.addAttribute("customers", listCustomers);
System.out.println(listCustomers);
return "customer-list";
}

//@RequestMapping("/showFormForAdd")
@GetMapping("/showFormForAdd")
public String showFormForAdd(Model model) {
Customer cust = new Customer();
model.addAttribute("customer", cust);
return "customer-form";
}

//@RequestMapping("/saveCustomer")
@PostMapping("/saveCustomer")
public String saveCustomer(@Valid @ModelAttribute("customer") Customer cust,BindingResult bind) {
	
	if(bind.hasErrors()) {
		System.out.println(bind);
		return "customer-form";
	}
	else {
		customerService.saveCustomer(cust);
		return "redirect:/customer/list";
	}

}

//@RequestMapping("/showFormForUpdate")
@GetMapping("/showFormForUpdate")
public String showFormForUpdate(@RequestParam("customerId") int theId, Model themodel) {
Customer customer = customerService.getCustomer(theId);
themodel.addAttribute("customer", customer);
return "customer-form";

}

@GetMapping("/searchCustomer")
public String searchCustomer(@RequestParam("val") String val,Model custModel) {
	List<Customer> searchList=customerService.getCustomerbyNameorId(val);
	custModel.addAttribute("customers",searchList);
	return "customer-list";
}

//@RequestMapping("/delete")
@GetMapping("/delete")
public String deleteCustomer(@RequestParam("customerId") int theId)
{
customerService.deleteCustomer(theId);
return "redirect:/customer/list";
}
}

