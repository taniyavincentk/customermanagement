package com.cognizant.project.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cognizant.project.entity.Customer;
@Repository
@Transactional
public class CustomerDaoImp implements CustomerDAO {

@Autowired
private SessionFactory factory;
@Override
@Transactional
public List<Customer> getAllCustomers()
{
Session session=factory.getCurrentSession();
Query<Customer> query=session.createQuery("from Customer order by firstName",Customer.class);
List<Customer> listOfCust= query.getResultList();
System.out.println("****");
listOfCust.forEach(s -> System.out.println(s));
System.out.println("****");
return listOfCust;
}


@Override
@Transactional
public void saveCustomer(Customer cust)
{
Session session=factory.getCurrentSession();
session.saveOrUpdate(cust);
}


@Override
@Transactional
public Customer getCustomer(int theId)
{
Session session=factory.getCurrentSession();
Customer cust=session.get(Customer.class, theId);
return cust;
}


@Override
@Transactional
public void deleteCustomer(int theId) {
Session session=factory.getCurrentSession();
Customer c=session.get(Customer.class, theId);
session.delete(c);
System.out.println(theId+":Customer deleted");
}


@Override
@Transactional
public List<Customer> getCustomerbyNameorId(String val) {
	Session session=factory.getCurrentSession();
	Query<Customer> query=session.createQuery("from Customer where firstName like '"+val+"%' or "
			+ "lastName like '"+val+"%' or concat(firstName,lastName) "
					+ "like '"+val+"%' or id='"+val+"%' order by id");
	List<Customer> custList=query.getResultList();
	return custList;
}




}

